ScreenSync MCP hub — repo-free install

1. Install Node.js 18+ (nodejs.org) if you do not have it.
2. Windows: double-click start-hub.bat
   macOS/Linux: run  sh start-hub.sh  (or: node screensync-hub.js)
3. The terminal prints a pairing link + QR code and serves on http://localhost:3000

This zip is rebuilt from the GitHub repo on every release, so it is always
the latest hub. Scan the QR with the ScreenSync Android app, then load the
browser extension (download it from the same site) to give agents your browser.

Optional env vars: SCREEN_SYNC_PORT, SCREEN_SYNC_HOST, SCREEN_SYNC_TOKEN,
SCREEN_SYNC_ADB_BIN (path to adb for phone tools), SCREEN_SYNC_DATA_DIR.
