import path from "node:path";
import { fileURLToPath } from "node:url";

const currentDir = path.dirname(fileURLToPath(import.meta.url));
export const PROJECT_DIR =
  path.basename(currentDir) === "dist" ? path.dirname(currentDir) : currentDir;

export const DATA_DIR = process.env.SCREEN_SYNC_DATA_DIR || path.join(PROJECT_DIR, "data");
export const FRAMES_DIR = path.join(DATA_DIR, "frames");
export const ARCHIVE_DIR = path.join(DATA_DIR, "archive");
export const INSPECTIONS_FILE = path.join(DATA_DIR, "latest_inspection.json");
export const PATCHES_FILE = path.join(DATA_DIR, "latest_patch.json");

export const HTTP_PORT = Number(process.env.SCREEN_SYNC_PORT || 3000);
export const HTTP_HOST = process.env.SCREEN_SYNC_HOST || "0.0.0.0";
export const AUTH_TOKEN = process.env.SCREEN_SYNC_TOKEN || "screensync-local-dev";

export const MAX_FRAMES = 20;
export const MAX_ARCHIVE = 100; // prune archive when it exceeds this many frames
export const MAX_BODY_BYTES = "18mb";

/**
 * Pairing window for the unauthenticated /pair + /api/pair endpoints, in
 * minutes. The token is served while no device has paired yet OR within this
 * window after hub start; afterwards a restart (or 0 = always open) is needed.
 */
export const PAIR_WINDOW_MINUTES = Number(process.env.SCREEN_SYNC_PAIR_WINDOW_MINUTES ?? "10");

/** Default AI agent label surfaced on the phone. Override via env SCREEN_SYNC_AGENT_NAME. */
export const agentName = process.env.SCREEN_SYNC_AGENT_NAME || "Claude";

export function log(level: string, message: string, context: Record<string, unknown> = {}) {
  console.error(JSON.stringify({ timestamp: new Date().toISOString(), level, message, ...context }));
}

export function isAuthorized(header: string | undefined): boolean {
  return header === `Bearer ${AUTH_TOKEN}`;
}
