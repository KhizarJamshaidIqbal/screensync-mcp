@echo off
node "%~dp0screensync-hub.js"
pause
